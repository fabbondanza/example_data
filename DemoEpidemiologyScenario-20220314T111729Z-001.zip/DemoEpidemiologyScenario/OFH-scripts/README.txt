Utilizing Cohort Browsers and Showcasing Graphical User Inferfaces / Graphical Interactive Methods 

1. Cohort Selection 
- The code in DemoEpidemiologyScenario/1-tre-test-prep.ipynb does not necessarily need to be completed via the notebook.
- If possible, we would like to observe how the relevant cohorts can be selected and joined using graphical interactive methods (such as a cohort browser).
- This can be done instead of or in addition to the relevant preprocessing steps performed in DemoEpidemiologyScenario/1-tre-test-prep.ipynb.
- The cohort selection steps are as follows: join the OFH_Questionnaire_clean dataset with the HES_APC_ADMISSIONS_DIAGNOSES dataset on the 'PID' key (participant ID). Include ONLY diabetic participants from the HES dataset that have the value 'E10.0' in any of the 'diag{i}_icd10' columns. This should result in one additional column appended to the OFH_Questionnaire_clean dataset, and multiple rows.  
- A 'Diabetes Only' dataset can be filtered to include only participants with the value '6' present in the 'q-019f4cea-245c-43f4-b0f5-bcb00b1fc8b2' column within the OFH_Questionnaire_clean dataset (alias 'primary diagnoses') or 'E10.0' in the additional column arising from the previous left join (i.e. from the HES dataset).

2. Visualising data
- As above, the results from DemoEpidemiologyScenario/2-tre-test-desc.ipynb may be shown via a GUI method. 
- Descriptive statistics for example, the total number of diabetic and non-diabetic participants, stratified by gender, could be shown via a Cohort Browser / GUI
- The creation of figures, e.g. a histogram representing the total number of diabetic and non-diabetic participants, stratified by gender, could also be shown via a Cohort Browser / GUI  
- If the tables and figures cannot be saved to the 'workspace' then please do use an alternative method (i.e. python) to show how tables and figures can be saved and accessed. 

